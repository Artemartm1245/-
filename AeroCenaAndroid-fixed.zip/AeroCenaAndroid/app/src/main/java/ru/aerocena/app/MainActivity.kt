package ru.aerocena.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("aerocena", MODE_PRIVATE) }
    private lateinit var url: EditText
    private lateinit var interval: Spinner
    private lateinit var status: TextView
    private val channelId = "aerocena_alerts"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 24, 22, 22); setBackgroundColor(0xFFF5F7FA.toInt()) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, ViewGroup.LayoutParams(-1, -1))
        setContentView(root)

        content.addView(TextView(this).apply { text = "✈ АэроЦена"; textSize = 30f; setTextColor(0xFF123456.toInt()); gravity = Gravity.CENTER_VERTICAL })
        content.addView(TextView(this).apply { text = "Отслеживание билетов • LED ⇄ AER"; textSize = 16f; setPadding(0, 8, 0, 20) })
        content.addView(label("Ссылка на поиск Аэрофлота"))
        url = EditText(this).apply {
            setText(prefs.getString("url", "https://www.aeroflot.ru/sb/search/?adults=4&infants=0&children=0&cabin=economy&routes=LED.20261120.AER-AER.20261126.LED"))
            minLines = 3; maxLines = 5; gravity = Gravity.TOP; textSize = 13f
        }
        content.addView(url, matchWrap())
        content.addView(label("Интервал фоновой проверки"))
        interval = Spinner(this)
        interval.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("15 минут (Android разрешает в фоне)", "30 минут", "60 минут"))
        interval.setSelection(prefs.getInt("interval", 0).coerceIn(0, 2))
        content.addView(interval, matchWrap())
        content.addView(label("Даты отслеживания (4 взрослых, эконом)"))
        content.addView(TextView(this).apply {
            text = "19→25 ноября\n19→26 ноября\n19→27 ноября\n20→26 ноября\n20→27 ноября\n21→27 ноября 2026\n\nУведомления задуманы только при снижении общей цены."
            textSize = 16f; setPadding(16, 14, 16, 14); setBackgroundColor(0xFFFFFFFF.toInt())
        })
        val save = button("Сохранить и включить мониторинг") { saveAndSchedule() }
        content.addView(save, matchWrap())
        content.addView(button("Остановить мониторинг") { WorkManager.getInstance(this).cancelUniqueWork("aerocena_monitor"); showStatus("Мониторинг остановлен.") }, matchWrap())
        content.addView(button("🔔 Тест уведомления") { testNotification() }, matchWrap())
        content.addView(button("Открыть поиск Аэрофлота") {
            val target = url.text.toString().trim()
            if (target.startsWith("https://")) startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(target)))
            else Toast.makeText(this, "Нужна ссылка https://", Toast.LENGTH_LONG).show()
        }, matchWrap())
        status = TextView(this).apply { textSize = 14f; setPadding(0, 18, 0, 0); text = prefs.getString("status", "Мониторинг ещё не включён.") }
        content.addView(status, matchWrap())
        content.addView(TextView(this).apply {
            text = "Важно: приложение пока НЕ умеет надёжно получать реальные тарифы из сайта Аэрофлота. Сайт загружает результаты динамически и может блокировать автоматические запросы. Сейчас фоновая задача проверяет доступность страницы, а не цену. Не полагайтесь на него для реальных уведомлений о снижении тарифа. Android также не гарантирует работу каждые 5 минут; минимальный период фоновой задачи — 15 минут."
            textSize = 13f; setTextColor(0xFF9B2C2C.toInt()); setPadding(0, 20, 0, 20)
        })
    }

    private fun label(s: String) = TextView(this).apply { text = s; textSize = 15f; setPadding(0, 18, 0, 6) }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 10 }
    private fun button(s: String, action: () -> Unit) = Button(this).apply { text = s; setOnClickListener { action() } }

    private fun saveAndSchedule() {
        val link = url.text.toString().trim()
        if (!link.startsWith("https://www.aeroflot.ru/")) { Toast.makeText(this, "Введи ссылку на сайт aeroflot.ru", Toast.LENGTH_LONG).show(); return }
        val minutes = when (interval.selectedItemPosition) { 1 -> 30L; 2 -> 60L; else -> 15L }
        prefs.edit().putString("url", link).putInt("interval", interval.selectedItemPosition).apply()
        val request = PeriodicWorkRequestBuilder<CheckPageWorker>(minutes, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("aerocena_monitor", ExistingPeriodicWorkPolicy.UPDATE, request)
        showStatus("Мониторинг включён. Фоновая проверка доступности страницы примерно раз в $minutes мин. Цены пока не считываются.")
        Toast.makeText(this, "Настройки сохранены", Toast.LENGTH_SHORT).show()
    }

    private fun showStatus(s: String) { prefs.edit().putString("status", s).apply(); if (::status.isInitialized) status.text = s }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channelId, "АэроЦена", NotificationManager.IMPORTANCE_DEFAULT))
    }
    private fun testNotification() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 51); return
        }
        val n = NotificationCompat.Builder(this, channelId).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("АэроЦена: тест")
            .setContentText("Уведомления работают на этом устройстве.").setPriority(NotificationCompat.PRIORITY_DEFAULT).build()
        NotificationManagerCompat.from(this).notify(51, n)
        Toast.makeText(this, "Тестовое уведомление отправлено", Toast.LENGTH_SHORT).show()
    }
}

class CheckPageWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val p = applicationContext.getSharedPreferences("aerocena", Context.MODE_PRIVATE)
        val link = p.getString("url", "") ?: ""
        if (!link.startsWith("https://")) return Result.failure()
        return try {
            val conn = java.net.URL(link).openConnection() as java.net.HttpURLConnection
            conn.connectTimeout = 12000; conn.readTimeout = 12000; conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36")
            val code = conn.responseCode
            conn.disconnect()
            val stamp = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(Date())
            p.edit().putString("status", "Последняя проверка доступности страницы: $stamp. HTTP $code. Цена не считывалась.").apply()
            Result.success()
        } catch (e: Exception) {
            p.edit().putString("status", "Ошибка проверки страницы: ${e.javaClass.simpleName}. Цена не считывалась.").apply()
            Result.retry()
        }
    }
}
